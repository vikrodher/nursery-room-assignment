@extends('layout')
@section('title', 'Dashboard')
@section('content')
  @if(session('success'))
    <div class="alert success" role="status">{{ session('success') }}</div>
  @endif
  @if($errors->any())
    <div class="alert error" role="alert">
      <strong>Please fix the following:</strong>
      <ul>@foreach($errors->all() as $error)
      <li>{{ $error }}</li>@endforeach
      </ul>
    </div>
  @endif
  <div class="page-heading">
    <div><span class="eyebrow">WORKSPACE</span>
      <h1>{{ $user->tenant->name ?? 'Nursery workspace' }}</h1>
      <p class="muted">Manage nursery locations, rooms, children and live attendance.</p>
    </div><span class="role-pill">{{ ucfirst($user->role) }}</span>
  </div>
  <div class="stats">
    <div class="stat"><span>Nurseries</span><strong>{{ $nurseries->count() }}</strong></div>
    <div class="stat"><span>Rooms</span><strong>{{ $rooms->count() }}</strong></div>
    <div class="stat"><span>Children</span><strong>{{ $children->count() }}</strong></div>
    <div class="stat"><span>Checked in
        now</span><strong>{{ $children->filter(fn($c) => $c->checkIns->isNotEmpty())->count() }}</strong></div>
  </div>
  <div class="section-grid">
    <section class="panel">
      <div class="section-title">
        <div>
          <h2>Nurseries</h2>
          <p class="muted">Create each location in your group.</p>
        </div>
      </div>
      <form method="POST" action="{{ route('nurseries.store') }}" class="inline-form">@csrf<input name="name"
          placeholder="Nursery name" maxlength="120" required><input name="address" placeholder="Address (optional)"
          maxlength="255"><button class="button primary">Add nursery</button></form>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Nursery</th>
              <th>Address</th>
              <th>Rooms</th>
              <th>Children</th>
              <th></th>
            </tr>
          </thead>
          <tbody>@forelse($nurseries as $n)
            <tr>
              <td><strong>{{ $n->name }}</strong></td>
              <td>{{ $n->address ?: '—' }}</td>
              <td>{{ $n->rooms_count }}</td>
              <td>{{ $n->children_count }}</td>
              <td>
                <form method="POST" action="{{ route('nurseries.delete', $n) }}"
                  onsubmit="return confirm('Delete this nursery?')">@csrf @method('DELETE')<button class="link danger" {{ ($n->rooms_count || $n->children_count) ? 'disabled' : '' }}>Delete</button></form>
              </td>
          </tr>@empty<tr>
              <td colspan="5" class="empty">No nurseries yet. Create one above.</td>
            </tr>@endforelse
          </tbody>
        </table>
      </div>
    </section>
    <section class="panel">
      <h2>Add a room</h2>
      <p class="muted">Rooms belong to one nursery.</p>
      <form method="POST" action="{{ route('rooms.store') }}" class="stack">@csrf<label>Nursery<select name="nursery_id"
            required>
            <option value="">Choose nursery</option>@foreach($nurseries as $n)
            <option value="{{ $n->id }}">{{ $n->name }}</option>@endforeach
          </select></label><label>Room name<input name="name" maxlength="120" placeholder="e.g. Bluebirds"
            required></label><button class="button primary" {{ $nurseries->isEmpty() ? 'disabled' : '' }}>Create room</button>
      </form>
    </section>
    <section class="panel">
      <h2>Add a child</h2>
      <p class="muted">Assign the child to their home nursery.</p>
      <form method="POST" action="{{ route('children.store') }}" class="stack">@csrf<label>Nursery<select
            name="nursery_id" required>
            <option value="">Choose nursery</option>@foreach($nurseries as $n)
            <option value="{{ $n->id }}">{{ $n->name }}</option>@endforeach
          </select></label><label>Child's full name<input name="name" maxlength="120" required></label><button
          class="button primary" {{ $nurseries->isEmpty() ? 'disabled' : '' }}>Add child</button></form>
    </section>
    @if($user->role === 'manager')
      <section class="panel">
        <h2>Create staff or guardian login</h2>
        <p class="muted">You can assign one or more children to this parent in Parent–Child Assignments below.</p>
        <form method="POST" action="{{ route('users.store') }}" class="stack">@csrf<label>Full name<input name="name"
              maxlength="120" required></label><label>Email<input type="email" name="email"
              required></label><label>Temporary password<input type="password" name="password" minlength="8"
              required></label><label>Confirm password<input type="password" name="password_confirmation" minlength="8"
              required></label><label>Role<select name="role" id="new-role" required>
              <option value="staff">Staff</option>
              <option value="guardian">Parent / Guardian</option>
            </select></label><label id="child-choice">Linked child<select name="child_id">
              <option value="">Select a child for guardian</option>@foreach($children as $c)
              <option value="{{ $c->id }}">{{ $c->name }} — {{ $c->nursery?->name }}</option>@endforeach
            </select></label><button class="button dark">Create account</button></form>
        <script>const roleSelect = document.getElementById('new-role'), childChoice = document.getElementById('child-choice'); function syncRole() { childChoice.style.display = roleSelect.value === 'guardian' ? 'grid' : 'none'; childChoice.querySelector('select').required = roleSelect.value === 'guardian' } roleSelect.addEventListener('change', syncRole); syncRole();</script>
    </section>@endif
  </div>
  @if($user->role === 'manager')
    <section class="panel assignment-panel" style="margin-top:16px">
      <div class="section-title">
        <div>
          <h2>Parent–Child Assignments</h2>
          <p class="muted">Assign multiple children to an existing parent account. Adding children preserves current links.
          </p>
        </div>
      </div>
      <form method="POST" action="{{ route('assignments.store') }}" class="stack">@csrf
        <label>Parent / guardian account<select name="parent_id" required>
            <option value="">Choose parent account</option>@foreach($guardianAccounts as $parent)
              <option value="{{ $parent->id }}" @selected(old('parent_id') == $parent->id)>{{ $parent->name }} —
            {{ $parent->email }}</option>@endforeach
          </select></label>
        <label>Children to assign<select name="child_ids[]" multiple size="5" required>@foreach($children as $child)
          <option value="{{ $child->id }}" @selected(collect(old('child_ids', []))->contains($child->id))>
        {{ $child->name }} — {{ $child->nursery?->name }}</option>@endforeach
          </select><small class="muted">Hold Ctrl (Windows) to select more than one child.</small></label>
        <button class="button primary" {{ $guardianAccounts->isEmpty() || $children->isEmpty() ? 'disabled' : '' }}>Assign
          selected children</button>
      </form>
      <h3 style="margin-top:22px">Current assignments</h3>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Parent</th>
              <th>Email</th>
              <th>Assigned children</th>
              <th>Manage</th>
            </tr>
          </thead>
          <tbody>
            @forelse($guardianAccounts as $parent)
              <tr>
                <td><strong>{{ $parent->name }}</strong></td>
                <td>{{ $parent->email }}</td>
                <td>{{ $parent->children->pluck('name')->join(', ') ?: ($parent->child?->name ?? 'No children assigned') }}
                </td>
                <td>
                  <details>
                    <summary>Edit</summary>
                    <form method="POST" action="{{ route('assignments.update', $parent) }}" class="stack"
                      style="min-width:220px;margin-top:8px">@csrf @method('PUT')<label>Linked children<select
                          name="child_ids[]" multiple size="5">@foreach($children as $child)
                            <option value="{{ $child->id }}" @selected($parent->children->contains('id', $child->id) || ($parent->children->isEmpty() && $parent->child_id == $child->id))>{{ $child->name }} —
                          {{ $child->nursery?->name }}</option>@endforeach
                        </select></label><button class="button small">Save assignments</button></form>
                  </details>@foreach($parent->children as $linked)
                    <form method="POST" action="{{ route('assignments.delete', [$parent, $linked]) }}" style="display:inline"
                      onsubmit="return confirm('Remove {{ addslashes($linked->name) }} from this parent?')">@csrf
                  @method('DELETE')<button class="link danger">Remove {{ $linked->name }}</button></form> @endforeach
                </td>
            </tr>@empty<tr>
              <td colspan="4" class="empty">Create a parent/guardian login first, then assign children here.</td>
            </tr>@endforelse
          </tbody>
        </table>
      </div>
    </section>
  @endif
  <div class="section-grid lower-grid">
    <section class="panel wide">
      <h2>Room attendance</h2>
      <p class="muted">Check children in and out. Children can only enter rooms in their assigned nursery.</p>
      @forelse($rooms as $room)
        <div class="room-card">
          <div class="room-head">
            <div>
              <h3>{{ $room->name }}</h3><span class="muted">{{ $room->nursery?->name }}</span>
            </div><span class="count-pill">{{ $room->checkIns->count() }} present</span>
            <form method="POST" action="{{ route('rooms.delete', $room) }}" onsubmit="return confirm('Delete this room?')">
              @csrf @method('DELETE')<button class="link danger" {{ $room->checkIns()->exists() ? 'disabled' : '' }}>Delete
                room</button></form>
          </div>
          <div class="attendance-list">@forelse($room->checkIns as $active)
            <div class="attendance-row">
              <div><strong>{{ $active->child?->name }}</strong><small>Checked in
                  {{ $active->checked_in_at?->format('d M Y, h:i A') }}</small></div>
              <form method="POST" action="{{ route('attendance.checkout', $active) }}">@csrf<button
                  class="button small">Check out</button></form>
          </div>@empty<p class="empty">No children currently in this room.</p>@endforelse
          </div>
          <form method="POST" action="{{ route('attendance.checkin', $room) }}" class="inline-form checkin-form">@csrf<select
              name="child_id" required>
              <option value="">Select child to check in</option>
              @foreach($children->where('nursery_id', $room->nursery_id) as $child)@if($child->checkIns->isEmpty())
              <option value="{{ $child->id }}">{{ $child->name }}</option>@endif @endforeach
            </select><button class="button primary">Check in</button></form>
      </div>@empty<div class="empty">Create a nursery and room to begin attendance.</div>@endforelse
    </section>
    <section class="panel wide">
      <h2>Children</h2>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Child</th>
              <th>Nursery</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>@forelse($children as $child)
            <tr>
              <td><strong>{{ $child->name }}</strong></td>
              <td>{{ $child->nursery?->name }}</td>
              <td>@if($child->checkIns->isNotEmpty())<span class="status in">Checked in ·
              {{ $child->checkIns->first()->room?->name }}</span>@else<span class="status out">Checked
                  out</span>@endif</td>
              <td>
                <form method="POST" action="{{ route('children.delete', $child) }}"
                  onsubmit="return confirm('Delete this child?')">@csrf @method('DELETE')<button class="link danger" {{ ($child->checkIns()->exists() || $child->guardianUsers()->exists()) ? 'disabled' : '' }}>Delete</button>
                </form>
              </td>
          </tr>@empty<tr>
              <td colspan="4" class="empty">No children created yet.</td>
            </tr>@endforelse
          </tbody>
        </table>
      </div>
    </section>
    @if($user->role === 'manager')
      <section class="panel wide">
        <h2>Workspace accounts</h2>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Linked child</th>
                <th></th>
              </tr>
            </thead>
            <tbody>@foreach($users as $account)
              <tr>
                <td>{{ $account->name }} @if($account->id === $user->id)<span class="muted">(you)</span>@endif</td>
                <td>{{ $account->email }}</td>
                <td>{{ ucfirst($account->role) }}</td>
                <td>{{ $account->role === 'guardian' ? ($account->child?->name ?? 'Not linked') : '—' }}</td>
                <td>@if($account->role !== 'manager' && $account->id !== $user->id)
                  <form method="POST" action="{{ route('users.delete', $account) }}"
                    onsubmit="return confirm('Delete this account?')">@csrf @method('DELETE')<button
                class="link danger">Delete</button></form>@else<span class="muted">Protected</span>@endif
                </td>
            </tr>@endforeach
            </tbody>
          </table>
        </div>
    </section>@endif
  </div>
@endsection