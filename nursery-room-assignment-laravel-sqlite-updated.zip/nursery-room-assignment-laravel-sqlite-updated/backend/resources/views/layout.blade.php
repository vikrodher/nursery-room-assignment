<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Nest Care') · Nest Care</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>

<body>
    <header class="topbar"><a class="brand" href="{{ route('home') }}"><span class="mark">N</span> nest<span
                class="dot">.</span>care</a>@auth<div class="top-user"><span>{{ auth()->user()->name }} ·
                        {{ ucfirst(auth()->user()->role) }}</span>
                    <form method="POST" action="{{ route('logout') }}">@csrf<button class="button ghost" type="submit">Sign
                            out</button></form>
                </div>@endauth</header>
    <main class="container">@if(session('success'))
    <div class="notice success">{{ session('success') }}</div>@endif @if($errors->any())
            <div class="notice error"><strong>Please check the following:</strong>
                <ul>@foreach($errors->all() as $error)
                <li>{{ $error }}</li>@endforeach
                </ul>
        </div>@endif @yield('content')
    </main>
    <footer> Nest Care · Nursery room attendance and guardian portal </footer>
</body>

</html>