@extends('layout')
@section('title', 'Sign in')
@section('content')
    <div class="auth-grid">
        <section class="hero"><span class="eyebrow">NURSERY OPERATIONS, MADE SIMPLE</span>
            <h1>A calmer way to care for every child.</h1>
            <p>Manage nurseries, rooms, attendance and guardian access in one secure workspace.</p>
            <div class="hero-points"><span>✓ Real database records</span><span>✓ Separate nursery workspaces</span><span>✓
                    Guardian access tied to one child</span></div>
        </section>
        <div class="auth-panels">
            <section class="panel">
                <h2>Welcome back</h2>
                <p class="muted">Sign in to your nursery workspace.</p>
                <form method="POST" action="{{ route('login') }}" class="stack">@csrf<label>Email address<input type="email"
                            name="email" value="{{ old('email') }}" autocomplete="email"
                            required></label><label>Password<input type="password" name="password"
                            autocomplete="current-password" required></label><label class="check"><input type="checkbox"
                            name="remember" value="1"> Keep me signed in</label><button class="button primary"
                        type="submit">Sign in</button></form>
            </section>
            <section class="panel">
                <h2>Create a workspace</h2>
                <p class="muted">Your first account becomes the workspace manager. No demo accounts or sample records are
                    created.</p>
                <form method="POST" action="{{ route('register') }}" class="stack">@csrf<label>Your name<input name="name"
                            value="{{ old('name') }}" maxlength="120" required></label><label>Nursery group name<input
                            name="tenant_name" value="{{ old('tenant_name') }}" maxlength="160"
                            required></label><label>Email address<input type="email" name="email" value="{{ old('email') }}"
                            required></label><label>Password (minimum 8 characters)<input type="password" name="password"
                            minlength="8" required></label><label>Confirm password<input type="password"
                            name="password_confirmation" minlength="8" required></label><button class="button dark"
                        type="submit">Create workspace</button></form>
            </section>
        </div>
    </div>
@endsection