@extends('layout')
@section('title', 'Guardian portal')
@section('content')
<div class="page-heading">
    <div><span class="eyebrow">PARENT / GUARDIAN PORTAL</span>
        <h1>Hello, {{ $user->name }}</h1>
        <p class="muted">Attendance for children assigned to your account.</p>
    </div><span class="role-pill">Read only</span>
</div>
<div class="section-grid">@foreach($assignedChildren as $child)
    @php($childHistory = $history->where('child_id', $child->id))
    @php($active = $childHistory->firstWhere('checked_out_at', null))
    <section class="panel child-summary">
        <div class="child-avatar">{{ strtoupper(substr($child->name, 0, 1)) }}</div>
        <div class="child-details"><span class="eyebrow">YOUR CHILD</span>
            <h2>{{ $child->name }}</h2>
            <p class="muted">{{ $child->nursery?->name ?? 'Nursery not assigned' }}</p>
        </div>
        <div class="child-status">@if($active)<span class="status in">Currently checked
            in</span><strong>{{ $active->room?->name }}</strong><small>Since
        {{ $active->checked_in_at?->format('d M Y, h:i A') }}</small>@else<span class="status out">Currently
                checked out</span>@endif</div>
    </section>
    <section class="panel">
        <h2>{{ $child->name }} — Attendance history</h2>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Room</th>
                        <th>Check-in</th>
                        <th>Check-out</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>@forelse($childHistory as $record)
                    <tr>
                        <td>{{ $record->checked_in_at?->format('d M Y') }}</td>
                        <td>{{ $record->room?->name ?? '—' }}</td>
                        <td>{{ $record->checked_in_at?->format('h:i A') }}</td>
                        <td>{{ $record->checked_out_at?->format('h:i A') ?? '—' }}</td>
                        <td>@if($record->checked_out_at)<span class="status out">Checked out</span>@else<span
                        class="status in">Present</span>@endif</td>
                </tr>@empty<tr>
                        <td colspan="5" class="empty">No attendance records yet.</td>
                    </tr>@endforelse
                </tbody>
            </table>
        </div>
    </section>
    @endforeach
</div>
@endsection