<?php

namespace Tests\Feature;

use App\Models\Child;
use App\Models\Nursery;
use App\Models\Room;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class RoomCheckInTest extends TestCase
{
    use RefreshDatabase;

    private function asTenant(string $tenant): User
    {
        Tenant::query()->firstOrCreate(['id' => $tenant], ['name' => strtoupper($tenant)]);
        $user = User::query()->firstOrCreate(['email' => "manager@{$tenant}.test"], [
            'tenant_id' => $tenant, 'name' => "Manager {$tenant}", 'password' => Hash::make('TestPassword123!'),
        ]);
        Sanctum::actingAs($user);
        return $user;
    }

    private function makeNursery(string $tenant, string $name = 'Sunrise'): Nursery
    {
        return Nursery::query()->create(['tenant_id' => $tenant, 'name' => $name]);
    }

    private function makeRoom(string $tenant, ?Nursery $nursery = null, string $name = 'Sunflowers'): Room
    {
        $nursery ??= $this->makeNursery($tenant);
        return Room::query()->create(['tenant_id' => $tenant, 'nursery_id' => $nursery->id, 'name' => $name]);
    }

    private function makeChild(string $tenant, string $name): Child
    {
        $nursery = Nursery::query()->where('tenant_id', $tenant)->first() ?? $this->makeNursery($tenant);
        return Child::query()->create(['tenant_id' => $tenant, 'nursery_id' => $nursery->id, 'name' => $name]);
    }

    public function test_child_can_check_in_and_appear_in_occupants(): void
    {
        $this->asTenant('tenant-a');
        $room = $this->makeRoom('tenant-a');
        $child = $this->makeChild('tenant-a', 'Ava');
        $this->postJson("/api/rooms/{$room->id}/check-ins", ['child_id' => $child->id])->assertCreated();
        $this->getJson("/api/rooms/{$room->id}/occupants")->assertOk()->assertJsonPath('data.0.child_name', 'Ava');
    }

    public function test_child_cannot_be_checked_into_two_rooms_even_across_nurseries(): void
    {
        $this->asTenant('tenant-a');
        $nurseryOne = $this->makeNursery('tenant-a', 'Sunrise');
        $nurseryTwo = $this->makeNursery('tenant-a', 'Oak Tree');
        $roomOne = $this->makeRoom('tenant-a', $nurseryOne, 'Sunflowers');
        $roomTwo = $this->makeRoom('tenant-a', $nurseryTwo, 'Little Acorns');
        $child = Child::query()->create(['tenant_id' => 'tenant-a', 'nursery_id' => $nurseryOne->id, 'name' => 'Ava']);
        $this->postJson("/api/rooms/{$roomOne->id}/check-ins", ['child_id' => $child->id])->assertCreated();
        $this->postJson("/api/rooms/{$roomTwo->id}/check-ins", ['child_id' => $child->id])->assertStatus(409);
    }

    public function test_child_cannot_check_into_a_room_in_a_different_nursery(): void
    {
        $this->asTenant('tenant-a');
        $enrolledNursery = $this->makeNursery('tenant-a', 'Enrolled Nursery');
        $otherNursery = $this->makeNursery('tenant-a', 'Other Nursery');
        $room = $this->makeRoom('tenant-a', $otherNursery, 'Other Room');
        $child = Child::query()->create([
            'tenant_id' => 'tenant-a', 'nursery_id' => $enrolledNursery->id, 'name' => 'Assigned Child',
        ]);

        $this->postJson("/api/rooms/{$room->id}/check-ins", ['child_id' => $child->id])
            ->assertUnprocessable()->assertJsonValidationErrors('child_id');
    }

    public function test_checkout_removes_child_from_occupants_and_keeps_history(): void
    {
        $this->asTenant('tenant-a');
        $room = $this->makeRoom('tenant-a');
        $child = $this->makeChild('tenant-a', 'Ava');
        $checkInId = $this->postJson("/api/rooms/{$room->id}/check-ins", ['child_id' => $child->id])->assertCreated()->json('data.id');
        $this->postJson("/api/check-ins/{$checkInId}/check-out")->assertOk();
        $this->getJson("/api/rooms/{$room->id}/occupants")->assertOk()->assertJsonCount(0, 'data');
        $this->assertDatabaseHas('check_ins', ['id' => $checkInId, 'tenant_id' => 'tenant-a']);
    }

    public function test_tenant_cannot_view_or_change_another_tenants_checkin(): void
    {
        $this->asTenant('tenant-a');
        $room = $this->makeRoom('tenant-a');
        $child = $this->makeChild('tenant-a', 'Ava');
        $checkInId = $this->postJson("/api/rooms/{$room->id}/check-ins", ['child_id' => $child->id])->assertCreated()->json('data.id');
        $this->asTenant('tenant-b');
        $this->getJson("/api/rooms/{$room->id}/occupants")->assertNotFound();
        $this->postJson("/api/check-ins/{$checkInId}/check-out")->assertNotFound();
    }

    public function test_tenant_cannot_check_in_child_from_another_tenant(): void
    {
        $this->asTenant('tenant-a');
        $room = $this->makeRoom('tenant-a');
        $this->asTenant('tenant-b');
        $childB = $this->makeChild('tenant-b', 'Oliver');
        $this->asTenant('tenant-a');
        $this->postJson("/api/rooms/{$room->id}/check-ins", ['child_id' => $childB->id])->assertUnprocessable();
    }

    public function test_crud_endpoints_only_return_records_for_authenticated_tenant_even_if_header_is_spoofed(): void
    {
        $this->asTenant('tenant-a');
        $this->makeNursery('tenant-a', 'Sunrise');
        $this->makeNursery('tenant-b', 'Private Nursery');
        $this->withHeader('X-Tenant-ID', 'tenant-b')->getJson('/api/nurseries')->assertOk()
            ->assertJsonCount(1, 'data')->assertJsonMissing(['name' => 'Private Nursery']);
    }

    public function test_tenant_cannot_create_room_inside_another_tenants_nursery(): void
    {
        $nurseryB = $this->makeNursery('tenant-b', 'B nursery');
        $this->asTenant('tenant-a');
        $this->postJson('/api/rooms', ['nursery_id' => $nurseryB->id, 'name' => 'Intruding room'])->assertUnprocessable();
    }

    public function test_tenant_cannot_update_or_delete_another_tenants_nursery(): void
    {
        $nurseryB = $this->makeNursery('tenant-b', 'Private Nursery');
        $this->asTenant('tenant-a');
        $this->patchJson('/api/nurseries/'.$nurseryB->id, ['name' => 'Hacked Name'])->assertNotFound();
        $this->deleteJson('/api/nurseries/'.$nurseryB->id)->assertNotFound();
        $this->assertDatabaseHas('nurseries', ['id' => $nurseryB->id, 'tenant_id' => 'tenant-b', 'name' => 'Private Nursery']);
    }
}
