<?php

namespace Tests\Feature;

use App\Models\Nursery;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ManagementTest extends TestCase
{
    use RefreshDatabase;

    private function signIn(string $tenantId): User
    {
        Tenant::query()->firstOrCreate(['id' => $tenantId], ['name' => strtoupper($tenantId)]);
        $user = User::query()->firstOrCreate(['email' => "owner+{$tenantId}@example.test"], [
            'tenant_id' => $tenantId, 'name' => "Owner {$tenantId}", 'password' => Hash::make('TestPassword123!'), 'role' => 'manager',
        ]);
        Sanctum::actingAs($user);
        return $user;
    }

    public function test_nursery_room_and_child_records_are_created_and_persisted(): void
    {
        $this->signIn('tenant-a');
        $nurseryId = $this->postJson('/api/nurseries', ['name' => 'Harbour Nursery', 'address' => '1 Harbour Road'])
            ->assertCreated()->json('data.id');
        $roomId = $this->postJson('/api/rooms', ['nursery_id' => $nurseryId, 'name' => 'Daisies'])
            ->assertCreated()->json('data.id');
        $childId = $this->postJson('/api/children', ['nursery_id' => $nurseryId, 'name' => 'Child Example'])
            ->assertCreated()->json('data.id');

        $this->assertDatabaseHas('nurseries', ['id' => $nurseryId, 'tenant_id' => 'tenant-a', 'name' => 'Harbour Nursery']);
        $this->assertDatabaseHas('rooms', ['id' => $roomId, 'tenant_id' => 'tenant-a', 'nursery_id' => $nurseryId, 'name' => 'Daisies']);
        $this->assertDatabaseHas('children', ['id' => $childId, 'tenant_id' => 'tenant-a', 'nursery_id' => $nurseryId, 'name' => 'Child Example']);
    }

    public function test_user_can_add_another_user_to_own_tenant_only(): void
    {
        $this->signIn('tenant-a');
        $this->postJson('/api/users', [
            'name' => 'Staff Member', 'email' => 'staff@example.test',
            'password' => 'StaffPassword123!', 'password_confirmation' => 'StaffPassword123!',
        ])->assertCreated()->assertJsonPath('data.tenant_id', 'tenant-a')->assertJsonPath('data.role', 'staff');
        $this->getJson('/api/users')->assertOk()->assertJsonCount(2, 'data');
        $this->assertDatabaseHas('users', ['email' => 'staff@example.test', 'tenant_id' => 'tenant-a']);
    }

    public function test_tenant_cannot_list_or_mutate_another_tenants_users(): void
    {
        $this->signIn('tenant-b');
        $userB = User::query()->where('tenant_id', 'tenant-b')->firstOrFail();
        $this->signIn('tenant-a');
        $this->getJson('/api/users')->assertOk()->assertJsonMissing(['email' => $userB->email]);
        $this->patchJson('/api/users/'.$userB->id, ['name' => 'Changed'])->assertNotFound();
        $this->deleteJson('/api/users/'.$userB->id)->assertNotFound();
    }

    public function test_staff_can_create_nurseries_rooms_and_children(): void
    {
        Tenant::query()->create(['id' => 'staff-tenant', 'name' => 'Staff Tenant']);
        $staff = User::query()->create([
            'tenant_id' => 'staff-tenant', 'name' => 'Staff User', 'email' => 'staff-user@example.test',
            'password' => Hash::make('TestPassword123!'), 'role' => 'staff',
        ]);
        Sanctum::actingAs($staff);

        $nurseryId = $this->postJson('/api/nurseries', ['name' => 'New Nursery'])->assertCreated()->json('data.id');
        $this->postJson('/api/rooms', ['nursery_id' => $nurseryId, 'name' => 'Daisies'])->assertCreated();
        $this->postJson('/api/children', ['nursery_id' => $nurseryId, 'name' => 'Child One'])->assertCreated();

        $this->assertDatabaseHas('nurseries', ['id' => $nurseryId, 'tenant_id' => 'staff-tenant']);
        $this->assertDatabaseHas('rooms', ['nursery_id' => $nurseryId, 'tenant_id' => 'staff-tenant', 'name' => 'Daisies']);
        $this->assertDatabaseHas('children', ['nursery_id' => $nurseryId, 'tenant_id' => 'staff-tenant', 'name' => 'Child One']);
    }

    public function test_staff_cannot_access_staff_account_management_or_delete_manager(): void
    {
        Tenant::query()->create(['id' => 'roles-tenant', 'name' => 'Roles Tenant']);
        $manager = User::query()->create([
            'tenant_id' => 'roles-tenant', 'name' => 'Manager', 'email' => 'role-manager@example.test',
            'password' => Hash::make('TestPassword123!'), 'role' => 'manager',
        ]);
        $staff = User::query()->create([
            'tenant_id' => 'roles-tenant', 'name' => 'Staff', 'email' => 'role-staff@example.test',
            'password' => Hash::make('TestPassword123!'), 'role' => 'staff',
        ]);
        Sanctum::actingAs($staff);

        $this->getJson('/api/users')->assertForbidden();
        $this->postJson('/api/users', [
            'name' => 'Another Staff', 'email' => 'another-staff@example.test',
            'password' => 'StaffPassword123!', 'password_confirmation' => 'StaffPassword123!',
        ])->assertForbidden();
        $this->deleteJson('/api/users/'.$manager->id)->assertForbidden();
        $this->patchJson('/api/users/'.$manager->id, ['name' => 'Tampered Manager'])->assertForbidden();

        $this->assertDatabaseHas('users', ['id' => $manager->id, 'name' => 'Manager', 'role' => 'manager']);
    }

    public function test_manager_cannot_delete_a_manager_account(): void
    {
        Tenant::query()->create(['id' => 'manager-tenant', 'name' => 'Manager Tenant']);
        $manager = User::query()->create([
            'tenant_id' => 'manager-tenant', 'name' => 'Manager One', 'email' => 'manager-one@example.test',
            'password' => Hash::make('TestPassword123!'), 'role' => 'manager',
        ]);
        $otherManager = User::query()->create([
            'tenant_id' => 'manager-tenant', 'name' => 'Manager Two', 'email' => 'manager-two@example.test',
            'password' => Hash::make('TestPassword123!'), 'role' => 'manager',
        ]);
        Sanctum::actingAs($manager);
        $this->deleteJson('/api/users/'.$otherManager->id)->assertStatus(409);
        $this->assertDatabaseHas('users', ['id' => $otherManager->id, 'role' => 'manager']);
    }

}
