<?php

namespace Tests\Feature;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Tenant::query()->create(['id' => 'tenant-a', 'name' => 'Test Nursery Group']);
        User::query()->create([
            'tenant_id' => 'tenant-a',
            'name' => 'Test Manager',
            'email' => 'manager@example.test',
            'password' => Hash::make('TestPassword123!'),
            'role' => 'manager',
        ]);
    }

    public function test_registration_creates_tenant_and_first_user_without_demo_data(): void
    {
        $response = $this->postJson('/api/auth/register', [
            'name' => 'New Owner',
            'tenant_name' => 'My Nursery Group',
            'email' => 'owner@my-nursery.test',
            'password' => 'A-strong-password-123',
            'password_confirmation' => 'A-strong-password-123',
        ])->assertCreated()->assertJsonStructure(['token', 'user' => ['id', 'name', 'email', 'tenant_id', 'tenant_name', 'role']])
            ->assertJsonPath('user.role', 'manager');

        $this->assertDatabaseHas('tenants', ['name' => 'My Nursery Group']);
        $this->assertDatabaseHas('users', ['email' => 'owner@my-nursery.test', 'name' => 'New Owner']);
        $this->assertDatabaseCount('nurseries', 0);
        $this->assertDatabaseCount('rooms', 0);
        $this->assertDatabaseCount('children', 0);
    }

    public function test_registration_rejects_duplicate_email_and_unconfirmed_password(): void
    {
        $this->postJson('/api/auth/register', [
            'name' => 'Another Owner', 'tenant_name' => 'Another Group',
            'email' => 'manager@example.test', 'password' => 'Password123!', 'password_confirmation' => 'Password123!',
        ])->assertUnprocessable()->assertJsonValidationErrors('email');

        $this->postJson('/api/auth/register', [
            'name' => 'Another Owner', 'tenant_name' => 'Another Group',
            'email' => 'another@example.test', 'password' => 'Password123!', 'password_confirmation' => 'not-same',
        ])->assertUnprocessable()->assertJsonValidationErrors('password');
    }

    public function test_valid_credentials_return_a_bearer_token_and_profile(): void
    {
        $this->postJson('/api/auth/login', ['email' => 'manager@example.test', 'password' => 'TestPassword123!'])
            ->assertOk()->assertJsonStructure(['token', 'user' => ['id', 'name', 'email', 'tenant_id', 'tenant_name']]);
    }

    public function test_invalid_credentials_are_rejected(): void
    {
        $this->postJson('/api/auth/login', ['email' => 'manager@example.test', 'password' => 'wrong-password'])
            ->assertUnprocessable()->assertJsonValidationErrors('email');
    }

    public function test_private_api_requires_authentication(): void
    {
        $this->getJson('/api/nurseries')->assertUnauthorized();
    }

    public function test_authenticated_profile_and_logout_work(): void
    {
        $response = $this->postJson('/api/auth/login', ['email' => 'manager@example.test', 'password' => 'TestPassword123!'])->assertOk();
        $token = $response->json('token');
        $this->withToken($token)->getJson('/api/auth/me')->assertOk()->assertJsonPath('user.email', 'manager@example.test');
        $this->withToken($token)->postJson('/api/auth/logout')->assertOk();
    }
}
