<?php

namespace Tests\Feature;

use App\Models\CheckIn;
use App\Models\Child;
use App\Models\Nursery;
use App\Models\Room;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class GuardianAccessTest extends TestCase
{
    use RefreshDatabase;

    private function manager(): User
    {
        Tenant::query()->create(['id' => 'guardian-tenant', 'name' => 'Guardian Group']);
        $manager = User::query()->create([
            'tenant_id' => 'guardian-tenant', 'name' => 'Manager', 'email' => 'guardian-manager@example.test',
            'password' => Hash::make('TestPassword123!'), 'role' => 'manager',
        ]);
        Sanctum::actingAs($manager);
        return $manager;
    }

    public function test_manager_can_create_guardian_account_linked_to_child(): void
    {
        $this->manager();
        $nursery = Nursery::query()->create(['tenant_id' => 'guardian-tenant', 'name' => 'North Nursery']);
        $child = Child::query()->create(['tenant_id' => 'guardian-tenant', 'nursery_id' => $nursery->id, 'name' => 'Robin Child']);

        $this->postJson('/api/users', [
            'name' => 'Robin Parent', 'email' => 'robin-parent@example.test',
            'password' => 'ParentPassword123!', 'password_confirmation' => 'ParentPassword123!',
            'role' => 'guardian', 'child_id' => $child->id,
        ])->assertCreated()->assertJsonPath('data.role', 'guardian')->assertJsonPath('data.child_id', $child->id)
            ->assertJsonPath('data.child_name', 'Robin Child');

        $this->assertDatabaseHas('users', ['email' => 'robin-parent@example.test', 'role' => 'guardian', 'child_id' => $child->id]);
    }

    public function test_guardian_only_sees_linked_child_attendance_and_cannot_use_staff_apis(): void
    {
        $this->manager();
        $nursery = Nursery::query()->create(['tenant_id' => 'guardian-tenant', 'name' => 'North Nursery']);
        $room = Room::query()->create(['tenant_id' => 'guardian-tenant', 'nursery_id' => $nursery->id, 'name' => 'Sunflowers']);
        $ownChild = Child::query()->create(['tenant_id' => 'guardian-tenant', 'nursery_id' => $nursery->id, 'name' => 'Robin Child']);
        $otherChild = Child::query()->create(['tenant_id' => 'guardian-tenant', 'nursery_id' => $nursery->id, 'name' => 'Other Child']);
        CheckIn::query()->create(['tenant_id' => 'guardian-tenant', 'room_id' => $room->id, 'child_id' => $ownChild->id, 'checked_in_at' => now()->subHour(), 'checked_out_at' => now()->subMinutes(30)]);
        CheckIn::query()->create(['tenant_id' => 'guardian-tenant', 'room_id' => $room->id, 'child_id' => $otherChild->id, 'checked_in_at' => now()]);
        $guardian = User::query()->create([
            'tenant_id' => 'guardian-tenant', 'name' => 'Robin Parent', 'email' => 'robin-parent@example.test',
            'password' => Hash::make('ParentPassword123!'), 'role' => 'guardian', 'child_id' => $ownChild->id,
        ]);
        Sanctum::actingAs($guardian);

        $this->getJson('/api/guardian/attendance')->assertOk()
            ->assertJsonPath('child.name', 'Robin Child')
            ->assertJsonCount(1, 'attendance')
            ->assertJsonPath('attendance.0.status', 'checked_out')
            ->assertJsonMissing(['child_name' => 'Other Child']);

        $this->getJson('/api/children')->assertForbidden();
        $this->getJson('/api/rooms')->assertForbidden();
        $this->getJson('/api/users')->assertForbidden();
        $this->postJson("/api/rooms/{$room->id}/check-ins", ['child_id' => $ownChild->id])->assertForbidden();
    }

    public function test_manager_cannot_link_guardian_to_child_in_another_tenant(): void
    {
        $this->manager();
        Tenant::query()->create(['id' => 'other-tenant', 'name' => 'Other Group']);
        $otherNursery = Nursery::query()->create(['tenant_id' => 'other-tenant', 'name' => 'Other Nursery']);
        $otherChild = Child::query()->create(['tenant_id' => 'other-tenant', 'nursery_id' => $otherNursery->id, 'name' => 'Private Child']);

        $this->postJson('/api/users', [
            'name' => 'Unauthorized Guardian', 'email' => 'unauthorized@example.test',
            'password' => 'ParentPassword123!', 'password_confirmation' => 'ParentPassword123!',
            'role' => 'guardian', 'child_id' => $otherChild->id,
        ])->assertUnprocessable();
    }
}
