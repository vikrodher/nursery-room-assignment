<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RequireTenant
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if (!$user || !$user->tenant_id) {
            return response()->json(['message' => 'An authenticated user with a tenant is required.'], 403);
        }

        // Never trust X-Tenant-ID from the browser. Tenant scope comes from the signed-in user.
        $request->attributes->set('tenant_id', (string) $user->tenant_id);

        return $next($request);
    }
}
