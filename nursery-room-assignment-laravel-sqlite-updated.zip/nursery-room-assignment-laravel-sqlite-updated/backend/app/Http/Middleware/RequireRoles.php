<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RequireRoles
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $role = (string) ($request->user()?->role ?? '');
        if (!in_array($role, $roles, true)) {
            return response()->json(['message' => 'Your account does not have permission to access this feature.'], 403);
        }

        return $next($request);
    }
}
