<?php

namespace App\Http\Controllers;

use App\Models\CheckIn;
use App\Models\Child;
use App\Models\Nursery;
use App\Models\Room;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpKernel\Exception\ConflictHttpException;

class WebController
{
    public function home() { return Auth::check() ? redirect()->route('dashboard') : view('auth'); }

    public function register(Request $request)
    {
        $request->merge(['email' => strtolower(trim((string)$request->email))]);
        $data = $request->validate([
            'name' => ['required','string','max:120'], 'tenant_name' => ['required','string','max:160'],
            'email' => ['required','email','max:255','unique:users,email'],
            'password' => ['required','string','min:8','confirmed'],
        ]);
        $user = DB::transaction(function () use ($data) {
            $tenant = Tenant::create(['id'=>(string)Str::uuid(),'name'=>trim($data['tenant_name'])]);
            return User::create(['tenant_id'=>$tenant->id,'name'=>trim($data['name']),'email'=>$data['email'],'password'=>$data['password'],'role'=>'manager']);
        });
        Auth::login($user); $request->session()->regenerate();
        return redirect()->route('dashboard')->with('success','Workspace created. Add your first nursery to get started.');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate(['email'=>['required','email'],'password'=>['required','string']]);
        $credentials['email'] = strtolower(trim($credentials['email']));
        if (!Auth::attempt($credentials, $request->boolean('remember'))) return back()->withErrors(['email'=>'Email or password is incorrect.'])->onlyInput('email');
        $request->session()->regenerate();
        return redirect()->route('dashboard');
    }

    public function logout(Request $request) { Auth::logout(); $request->session()->invalidate(); $request->session()->regenerateToken(); return redirect('/'); }

    public function dashboard(Request $request)
    {
        $user = $request->user(); $tenant = $user->tenant_id;
        if ($user->role === 'guardian') {
            $assignedChildren = $user->children()->where('children.tenant_id', $tenant)->with('nursery')->orderBy('name')->get();
            if ($assignedChildren->isEmpty() && $user->child_id) { $legacy = Child::where('tenant_id',$tenant)->whereKey($user->child_id)->with('nursery')->first(); if ($legacy) $assignedChildren = collect([$legacy]); }
            abort_unless($assignedChildren->isNotEmpty(), 403, 'This guardian account is not linked to a child.');
            $childIds = $assignedChildren->pluck('id');
            $history = CheckIn::where('tenant_id',$tenant)->whereIn('child_id',$childIds)->with(['room.nursery','child'])->latest('checked_in_at')->get();
            return view('guardian', compact('user','assignedChildren','history'));
        }
        $nurseries = Nursery::where('tenant_id',$tenant)->withCount(['rooms','children'])->orderBy('name')->get();
        $rooms = Room::where('tenant_id',$tenant)->with('nursery')->with(['checkIns'=>fn($q)=>$q->where('tenant_id',$tenant)->whereNull('checked_out_at')->with('child')])->orderBy('name')->get();
        $children = Child::where('tenant_id',$tenant)->with('nursery')->with(['checkIns'=>fn($q)=>$q->where('tenant_id',$tenant)->whereNull('checked_out_at')->with('room')])->orderBy('name')->get();
        $users = User::where('tenant_id',$tenant)->with(['child','children'])->orderBy('name')->get();
        $guardianAccounts = User::where('tenant_id',$tenant)->where('role','guardian')->with('children')->orderBy('name')->get();
        return view('dashboard', compact('user','nurseries','rooms','children','users','guardianAccounts'));
    }

    private function managerOrStaff(Request $request): string { abort_unless(in_array($request->user()->role,['manager','staff'],true),403); return (string)$request->user()->tenant_id; }
    private function manager(Request $request): string { abort_unless($request->user()->role==='manager',403,'Only a manager can manage user accounts.'); return (string)$request->user()->tenant_id; }

    public function saveNursery(Request $r)
    {
        $t = $this->managerOrStaff($r);
        // Normalize before validation so duplicate names are checked consistently.
        $r->merge([
            'name' => trim((string) $r->input('name', '')),
            'address' => trim((string) $r->input('address', '')),
        ]);
        $d = $r->validate([
            'name' => ['required', 'string', 'max:120', Rule::unique('nurseries', 'name')->where('tenant_id', $t)],
            'address' => ['nullable', 'string', 'max:255'],
        ]);

        Nursery::create([
            'tenant_id' => $t,
            'name' => $d['name'],
            'address' => ($d['address'] ?? '') !== '' ? $d['address'] : null,
        ]);

        return redirect()->route('dashboard')->with('success', 'Nursery created successfully.');
    }
    public function deleteNursery(Request $r, Nursery $nursery) { $t=$this->managerOrStaff($r); abort_unless($nursery->tenant_id===$t,404); if($nursery->rooms()->exists()||$nursery->children()->exists()) return back()->withErrors(['record'=>'This nursery still has rooms or children. Remove those records first.']); $nursery->delete(); return back()->with('success','Nursery deleted.'); }
    public function saveRoom(Request $r) { $t=$this->managerOrStaff($r); $d=$r->validate(['nursery_id'=>['required','integer',Rule::exists('nurseries','id')->where('tenant_id',$t)],'name'=>['required','string','max:120']]); Room::create(['tenant_id'=>$t,'nursery_id'=>$d['nursery_id'],'name'=>trim($d['name'])]); return back()->with('success','Room created.'); }
    public function deleteRoom(Request $r, Room $room) { $t=$this->managerOrStaff($r); abort_unless($room->tenant_id===$t,404); if($room->checkIns()->exists()) return back()->withErrors(['record'=>'This room has attendance history and cannot be deleted.']); $room->delete(); return back()->with('success','Room deleted.'); }
    public function saveChild(Request $r) { $t=$this->managerOrStaff($r); $d=$r->validate(['nursery_id'=>['required','integer',Rule::exists('nurseries','id')->where('tenant_id',$t)],'name'=>['required','string','max:120']]); $exists=Child::where('tenant_id',$t)->where('nursery_id',$d['nursery_id'])->whereRaw('LOWER(name)=?', [mb_strtolower(trim($d['name']))])->exists(); if($exists)return back()->withErrors(['name'=>'A child with this name already exists in this nursery.'])->withInput(); Child::create(['tenant_id'=>$t,'nursery_id'=>$d['nursery_id'],'name'=>trim($d['name'])]); return back()->with('success','Child created.'); }
    public function deleteChild(Request $r, Child $child) { $t=$this->managerOrStaff($r); abort_unless($child->tenant_id===$t,404); if($child->checkIns()->exists()||$child->guardianUsers()->exists()||$child->guardians()->exists()) return back()->withErrors(['record'=>'This child has attendance history or linked guardian accounts and cannot be deleted.']); $child->delete(); return back()->with('success','Child deleted.'); }

    public function saveUser(Request $r)
    {
        $t=$this->manager($r); $r->merge(['email'=>strtolower(trim((string)$r->email))]);
        $d=$r->validate(['name'=>['required','string','max:120'],'email'=>['required','email','max:255','unique:users,email'],'password'=>['required','string','min:8','confirmed'],'role'=>['required',Rule::in(['staff','guardian'])],'child_id'=>['nullable','integer',Rule::exists('children','id')->where('tenant_id',$t)]]);
        if($d['role']==='guardian' && empty($d['child_id'])) return back()->withErrors(['child_id'=>'Select the child this guardian is allowed to view.'])->withInput();
        if($d['role']==='staff') $d['child_id']=null;
        User::create(['tenant_id'=>$t,'name'=>trim($d['name']),'email'=>$d['email'],'password'=>$d['password'],'role'=>$d['role'],'child_id'=>$d['child_id']??null]); return back()->with('success','User account created.');
    }
    public function saveParentChildAssignments(Request $r)
    {
        $t = $this->manager($r);
        $d = $r->validate([
            'parent_id' => ['required','integer',Rule::exists('users','id')->where('tenant_id',$t)->where('role','guardian')],
            'child_ids' => ['required','array','min:1'],
            'child_ids.*' => ['integer','distinct',Rule::exists('children','id')->where('tenant_id',$t)],
        ]);
        $parent = User::where('tenant_id',$t)->where('role','guardian')->findOrFail($d['parent_id']);
        $sync = []; foreach ($d['child_ids'] as $id) $sync[$id] = ['tenant_id' => $t];
        // Attach only missing relationships: never remove assignments during Add.
        $parent->children()->syncWithoutDetaching($sync);
        if (!$parent->child_id) $parent->update(['child_id' => $d['child_ids'][0]]);
        return back()->with('success', 'Selected children assigned to '.$parent->name.'. Existing assignments were preserved.');
    }

    public function updateParentChildAssignments(Request $r, User $parent)
    {
        $t = $this->manager($r); abort_unless($parent->tenant_id === $t && $parent->role === 'guardian', 404);
        $d = $r->validate(['child_ids' => ['present','array'], 'child_ids.*' => ['integer','distinct',Rule::exists('children','id')->where('tenant_id',$t)]]);
        $sync = []; foreach ($d['child_ids'] as $id) $sync[$id] = ['tenant_id' => $t];
        DB::transaction(function () use ($parent, $sync, $d) {
            $parent->children()->sync($sync);
            $parent->update(['child_id' => count($d['child_ids']) ? $d['child_ids'][0] : null]);
        });
        return back()->with('success', 'Parent-child assignments updated.');
    }

    public function removeParentChildAssignment(Request $r, User $parent, Child $child)
    {
        $t = $this->manager($r); abort_unless($parent->tenant_id === $t && $parent->role === 'guardian' && $child->tenant_id === $t, 404);
        $parent->children()->detach($child->id);
        if ((int)$parent->child_id === (int)$child->id) { $next = $parent->children()->orderBy('children.name')->first(); $parent->update(['child_id' => $next?->id]); }
        return back()->with('success', 'Child assignment removed. The parent account was kept.');
    }

    public function deleteUser(Request $r, User $target) { $t=$this->manager($r); abort_unless($target->tenant_id===$t,404); if($target->id===$r->user()->id) return back()->withErrors(['record'=>'You cannot delete your own signed-in account.']); if($target->role==='manager') return back()->withErrors(['record'=>'Manager accounts cannot be deleted here.']); $target->delete(); return back()->with('success','User deleted.'); }

    public function checkIn(Request $r, Room $room)
    {
        $t=$this->managerOrStaff($r); abort_unless($room->tenant_id===$t,404);
        $d=$r->validate(['child_id'=>['required','integer',Rule::exists('children','id')->where('tenant_id',$t)]]);
        $child=Child::where('tenant_id',$t)->findOrFail($d['child_id']);
        if((int)$child->nursery_id !== (int)$room->nursery_id) return back()->withErrors(['attendance'=>'This child belongs to a different nursery.']);
        if(CheckIn::where('tenant_id',$t)->where('child_id',$child->id)->whereNull('checked_out_at')->exists()) return back()->withErrors(['attendance'=>'This child is already checked in. Check them out first.']);
        CheckIn::create(['tenant_id'=>$t,'room_id'=>$room->id,'child_id'=>$child->id,'checked_in_at'=>now()]); return back()->with('success',$child->name.' checked in.');
    }
    public function checkOut(Request $r, CheckIn $checkIn) { $t=$this->managerOrStaff($r); abort_unless($checkIn->tenant_id===$t,404); if($checkIn->checked_out_at) return back()->withErrors(['attendance'=>'This child has already been checked out.']); $checkIn->update(['checked_out_at'=>now()]); return back()->with('success',$checkIn->child->name.' checked out.'); }
}
