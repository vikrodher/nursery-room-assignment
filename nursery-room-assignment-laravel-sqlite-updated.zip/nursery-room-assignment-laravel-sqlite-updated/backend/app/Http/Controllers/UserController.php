<?php

namespace App\Http\Controllers;

use App\Models\Child;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpKernel\Exception\ConflictHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class UserController
{
    public function index(Request $request): JsonResponse
    {
        $this->requireManager($request);
        $tenant = (string) $request->attributes->get('tenant_id');
        $users = User::query()->where('tenant_id', $tenant)->with(['tenant', 'child'])->orderBy('name')->get();
        return response()->json(['data' => $users->map(fn (User $user) => $user->publicProfile())]);
    }

    public function store(Request $request): JsonResponse
    {
        $this->requireManager($request);
        $request->merge([
            'email' => strtolower(trim((string) $request->input('email'))),
            'role' => $request->input('role', 'staff'),
        ]);
        $tenant = (string) $request->attributes->get('tenant_id');
        $role = (string) $request->input('role');
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')],
            'password' => ['required', 'string', 'min:8', 'max:200', 'confirmed'],
            'role' => ['required', Rule::in(['staff', 'guardian'])],
            'child_id' => [
                Rule::requiredIf($role === 'guardian'),
                $role === 'guardian' ? 'integer' : 'prohibited',
                'nullable',
                Rule::exists('children', 'id')->where('tenant_id', $tenant),
            ],
        ]);

        if ($role === 'guardian' && !Child::query()->where('tenant_id', $tenant)->whereKey($data['child_id'] ?? 0)->exists()) {
            return response()->json(['message' => 'Select a child belonging to your nursery group.'], 422);
        }

        $user = User::query()->create([
            'tenant_id' => $tenant,
            'name' => trim($data['name']),
            'email' => strtolower(trim($data['email'])),
            'password' => $data['password'],
            'role' => $role,
            'child_id' => $role === 'guardian' ? (int) $data['child_id'] : null,
        ])->load(['tenant', 'child']);

        return response()->json(['data' => $user->publicProfile()], 201);
    }

    public function show(Request $request, int $user): JsonResponse
    {
        $this->requireManager($request);
        return response()->json(['data' => $this->findTenantUser($request, $user)->load(['tenant', 'child'])->publicProfile()]);
    }

    public function update(Request $request, int $user): JsonResponse
    {
        $this->requireManager($request);
        if ($request->exists('email')) $request->merge(['email' => strtolower(trim((string) $request->input('email')))]);
        $tenant = (string) $request->attributes->get('tenant_id');
        $record = $this->findTenantUser($request, $user);
        if ($record->role === 'manager' && ($request->exists('role') || $request->exists('child_id'))) {
            throw new ConflictHttpException('Manager role and child association cannot be changed through staff management.');
        }
        $effectiveRole = (string) $request->input('role', $record->role);
        $data = $request->validate([
            'name' => ['sometimes', 'required', 'string', 'max:120'],
            'email' => ['sometimes', 'required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($record->id)],
            'password' => ['sometimes', 'required', 'string', 'min:8', 'max:200', 'confirmed'],
            'role' => ['sometimes', 'required', Rule::in(['staff', 'guardian'])],
            'child_id' => [
                Rule::requiredIf($effectiveRole === 'guardian' && ($request->exists('role') || $record->role !== 'guardian')),
                $effectiveRole === 'guardian' ? 'sometimes' : 'prohibited',
                'nullable', 'integer',
                Rule::exists('children', 'id')->where('tenant_id', $tenant),
            ],
        ]);
        unset($data['password_confirmation']);
        if (($data['role'] ?? $record->role) === 'guardian') {
            $childId = $data['child_id'] ?? $record->child_id;
            if (!$childId || !Child::query()->where('tenant_id', $tenant)->whereKey($childId)->exists()) {
                return response()->json(['message' => 'Guardian accounts must be linked to a child in this nursery group.'], 422);
            }
            $data['child_id'] = (int) $childId;
        } else {
            $data['child_id'] = null;
        }
        $record->update($data);
        return response()->json(['data' => $record->refresh()->load(['tenant', 'child'])->publicProfile()]);
    }

    public function destroy(Request $request, int $user): JsonResponse
    {
        $this->requireManager($request);
        $tenant = (string) $request->attributes->get('tenant_id');
        $record = $this->findTenantUser($request, $user);
        if (($record->role ?? 'staff') === 'manager') {
            throw new ConflictHttpException('Manager accounts are protected and cannot be deleted.');
        }
        if ((int) $record->id === (int) $request->user()->id) {
            throw new ConflictHttpException('You cannot delete your own signed-in account.');
        }
        if (User::query()->where('tenant_id', $tenant)->count() <= 1) {
            throw new ConflictHttpException('The last user in a nursery group cannot be deleted.');
        }
        $record->tokens()->delete();
        $record->delete();
        return response()->json(['message' => 'User deleted.']);
    }

    private function requireManager(Request $request): void
    {
        if (($request->user()?->role ?? 'staff') !== 'manager') {
            abort(403, 'Only a manager can manage users and guardian access.');
        }
    }

    private function findTenantUser(Request $request, int $id): User
    {
        $record = User::query()->where('tenant_id', $request->attributes->get('tenant_id'))->find($id);
        if (!$record) throw new NotFoundHttpException('User not found for this nursery group.');
        return $record;
    }
}
