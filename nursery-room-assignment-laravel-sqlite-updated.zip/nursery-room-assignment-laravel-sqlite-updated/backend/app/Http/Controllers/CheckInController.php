<?php

namespace App\Http\Controllers;

use App\Services\CheckInService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CheckInController
{
    public function __construct(private readonly CheckInService $checkIns)
    {
    }

    public function store(Request $request, int $room): JsonResponse
    {
        $validated = $request->validate([
            'child_id' => ['required', 'integer', 'min:1'],
        ]);

        $checkIn = $this->checkIns->checkIn(
            (string) $request->attributes->get('tenant_id'),
            $room,
            (int) $validated['child_id']
        );

        $tenant = (string) $request->attributes->get('tenant_id');
        return response()->json(['data' => $checkIn->load([
            'child' => fn ($query) => $query->where('tenant_id', $tenant),
            'room' => fn ($query) => $query->where('tenant_id', $tenant),
        ])], 201);
    }

    public function checkOut(Request $request, int $checkIn): JsonResponse
    {
        $updated = $this->checkIns->checkOut(
            (string) $request->attributes->get('tenant_id'),
            $checkIn
        );

        $tenant = (string) $request->attributes->get('tenant_id');
        return response()->json(['data' => $updated->load([
            'child' => fn ($query) => $query->where('tenant_id', $tenant),
            'room' => fn ($query) => $query->where('tenant_id', $tenant),
        ])]);
    }
}
