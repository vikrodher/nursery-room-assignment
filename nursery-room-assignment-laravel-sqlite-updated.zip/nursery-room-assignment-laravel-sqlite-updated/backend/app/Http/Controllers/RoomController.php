<?php

namespace App\Http\Controllers;

use App\Models\Room;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpKernel\Exception\ConflictHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class RoomController
{
    public function index(Request $request): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $query = Room::query()->where('tenant_id', $tenant)->with(['nursery' => fn ($query) => $query->where('tenant_id', $tenant)->select('id', 'name')]);
        if ($request->filled('nursery_id')) $query->where('nursery_id', (int) $request->query('nursery_id'));
        return response()->json(['data' => $query->orderBy('name')->get()]);
    }

    public function store(Request $request): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $data = $request->validate([
            'nursery_id' => ['required', 'integer', Rule::exists('nurseries', 'id')->where('tenant_id', $tenant)],
            'name' => ['required', 'string', 'max:120'],
        ]);
        $duplicate = Room::query()->where('tenant_id', $tenant)->where('nursery_id', $data['nursery_id'])->where('name', $data['name'])->exists();
        if ($duplicate) return response()->json(['message' => 'A room with this name already exists in this nursery.'], 422);
        $room = Room::query()->create(['tenant_id' => $tenant, ...$data]);
        return response()->json(['data' => $room->load(['nursery' => fn ($query) => $query->where('tenant_id', $tenant)->select('id', 'name')])], 201);
    }

    public function show(Request $request, int $room): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $record = $this->findTenantRoom($request, $room);
        $record->load(['nursery' => fn ($query) => $query->where('tenant_id', $tenant)->select('id', 'name')]);
        return response()->json(['data' => $record]);
    }

    public function update(Request $request, int $room): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $record = $this->findTenantRoom($request, $room);
        $data = $request->validate([
            'nursery_id' => ['sometimes', 'required', 'integer', Rule::exists('nurseries', 'id')->where('tenant_id', $tenant)],
            'name' => ['sometimes', 'required', 'string', 'max:120'],
        ]);
        $nurseryId = (int) ($data['nursery_id'] ?? $record->nursery_id);
        if ($nurseryId !== (int) $record->nursery_id && $record->checkIns()->exists()) {
            throw new ConflictHttpException('A room with check-in history cannot be moved to another nursery.');
        }
        $name = $data['name'] ?? $record->name;
        $duplicate = Room::query()->where('tenant_id', $tenant)->where('nursery_id', $nurseryId)->where('name', $name)->where('id', '!=', $record->id)->exists();
        if ($duplicate) return response()->json(['message' => 'A room with this name already exists in this nursery.'], 422);
        $record->update([...$data, 'nursery_id' => $nurseryId]);
        return response()->json(['data' => $record->refresh()->load(['nursery' => fn ($query) => $query->where('tenant_id', $tenant)->select('id', 'name')] )]);
    }

    public function destroy(Request $request, int $room): JsonResponse
    {
        $record = $this->findTenantRoom($request, $room);
        if ($record->checkIns()->exists()) throw new ConflictHttpException('This room has check-in history; it cannot be deleted.');
        $record->delete();
        return response()->json(['message' => 'Room deleted.']);
    }

    private function findTenantRoom(Request $request, int $id): Room
    {
        $record = Room::query()->where('tenant_id', $request->attributes->get('tenant_id'))->find($id);
        if (!$record) throw new NotFoundHttpException('Room not found for this tenant.');
        return $record;
    }
}
