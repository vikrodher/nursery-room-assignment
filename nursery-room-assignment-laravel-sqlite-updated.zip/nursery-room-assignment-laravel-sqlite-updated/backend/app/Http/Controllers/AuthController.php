<?php

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class AuthController
{
    public function register(Request $request): JsonResponse
    {
        $request->merge(['email' => strtolower(trim((string) $request->input('email')))]);
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'tenant_name' => ['required', 'string', 'max:160'],
            'email' => ['required', 'string', 'email', 'max:255', Rule::unique('users', 'email')],
            'password' => ['required', 'string', 'min:8', 'max:200', 'confirmed'],
        ]);

        $user = DB::transaction(function () use ($data): User {
            $tenant = Tenant::query()->create([
                'id' => (string) Str::uuid(),
                'name' => trim($data['tenant_name']),
            ]);

            return User::query()->create([
                'tenant_id' => $tenant->id,
                'name' => trim($data['name']),
                'email' => strtolower(trim($data['email'])),
                'role' => 'manager',
                // User model's 'hashed' cast hashes the plain password.
                'password' => $data['password'],
            ]);
        });

        $user->load('tenant');
        return response()->json([
            'token' => $user->createToken('nursery-web')->plainTextToken,
            'user' => $user->publicProfile(),
        ], 201);
    }

    public function login(Request $request): JsonResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email', 'max:255'],
            'password' => ['required', 'string', 'max:200'],
        ]);

        $user = User::query()->where('email', strtolower(trim($credentials['email'])))->first();
        if (!$user || !Hash::check($credentials['password'], $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['Email or password is incorrect.'],
            ]);
        }

        $user->load('tenant');
        return response()->json([
            'token' => $user->createToken('nursery-web')->plainTextToken,
            'user' => $user->publicProfile(),
        ]);
    }

    public function me(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user()->load('tenant');
        return response()->json(['user' => $user->publicProfile()]);
    }

    public function logout(Request $request): JsonResponse
    {
        $token = $request->user()->currentAccessToken();
        if ($token && method_exists($token, 'delete')) $token->delete();
        return response()->json(['message' => 'Signed out successfully.']);
    }
}
