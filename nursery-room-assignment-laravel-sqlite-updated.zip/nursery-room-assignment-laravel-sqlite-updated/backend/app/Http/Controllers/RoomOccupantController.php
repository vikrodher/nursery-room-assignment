<?php

namespace App\Http\Controllers;

use App\Models\Room;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class RoomOccupantController
{
    public function __invoke(Request $request, int $room): JsonResponse
    {
        $tenantId = (string) $request->attributes->get('tenant_id');
        $roomModel = Room::query()->where('tenant_id', $tenantId)->with(['nursery' => fn ($query) => $query->where('tenant_id', $tenantId)->select('id', 'name')])->find($room);
        if (!$roomModel) throw new NotFoundHttpException('Room not found for this tenant.');

        $occupants = $roomModel->checkIns()->where('check_ins.tenant_id', $tenantId)
            ->whereNull('checked_out_at')->with('child:id,tenant_id,name')
            ->orderBy('checked_in_at')->get();

        return response()->json([
            'room' => ['id' => $roomModel->id, 'name' => $roomModel->name,
                'nursery_id' => $roomModel->nursery_id, 'nursery_name' => $roomModel->nursery->name],
            'data' => $occupants->map(static fn ($checkIn) => [
                'check_in_id' => $checkIn->id,
                'child_id' => $checkIn->child->id,
                'child_name' => $checkIn->child->name,
                'checked_in_at' => $checkIn->checked_in_at?->toISOString(),
            ])->values(),
        ]);
    }
}
