<?php

namespace App\Http\Controllers;

use App\Models\CheckIn;
use App\Models\Child;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\ForbiddenHttpException;

class GuardianAttendanceController
{
    public function __invoke(Request $request): JsonResponse
    {
        $user = $request->user();
        if (!$user || $user->role !== 'guardian' || !$user->child_id) {
            throw new ForbiddenHttpException('This page is only available to guardian accounts linked to a child.');
        }

        $tenantId = (string) $request->attributes->get('tenant_id');
        $child = Child::query()
            ->where('tenant_id', $tenantId)
            ->whereKey($user->child_id)
            ->with('nursery:id,name')
            ->first();

        if (!$child) {
            throw new ForbiddenHttpException('Your account is not linked to an active child record. Contact the nursery manager.');
        }

        $attendance = CheckIn::query()
            ->where('tenant_id', $tenantId)
            ->where('child_id', $child->id)
            ->with(['room:id,name,nursery_id', 'room.nursery:id,name'])
            ->orderByDesc('checked_in_at')
            ->get();

        $active = $attendance->firstWhere('checked_out_at', null);

        return response()->json([
            'child' => [
                'id' => $child->id,
                'name' => $child->name,
                'nursery_id' => $child->nursery_id,
                'nursery_name' => $child->nursery?->name,
            ],
            'current_status' => $active ? [
                'status' => 'checked_in',
                'room_name' => $active->room?->name,
                'nursery_name' => $active->room?->nursery?->name,
                'checked_in_at' => $active->checked_in_at?->toISOString(),
            ] : [
                'status' => 'not_checked_in',
                'room_name' => null,
                'nursery_name' => null,
                'checked_in_at' => null,
            ],
            'attendance' => $attendance->map(static fn (CheckIn $item) => [
                'check_in_id' => $item->id,
                'room_name' => $item->room?->name,
                'nursery_name' => $item->room?->nursery?->name,
                'checked_in_at' => $item->checked_in_at?->toISOString(),
                'checked_out_at' => $item->checked_out_at?->toISOString(),
                'status' => $item->checked_out_at ? 'checked_out' : 'checked_in',
            ])->values(),
        ]);
    }
}
