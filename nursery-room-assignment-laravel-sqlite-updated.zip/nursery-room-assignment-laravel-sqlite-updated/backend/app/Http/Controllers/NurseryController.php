<?php

namespace App\Http\Controllers;

use App\Models\Nursery;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpKernel\Exception\ConflictHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class NurseryController
{
    public function index(Request $request): JsonResponse
    {
        return response()->json(['data' => Nursery::query()
            ->where('tenant_id', $request->attributes->get('tenant_id'))
            ->withCount('rooms')->orderBy('name')->get()]);
    }

    public function store(Request $request): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120', Rule::unique('nurseries', 'name')->where('tenant_id', $tenant)],
            'address' => ['nullable', 'string', 'max:255'],
        ]);
        $nursery = Nursery::query()->create(['tenant_id' => $tenant, ...$data]);
        return response()->json(['data' => $nursery], 201);
    }

    public function show(Request $request, int $nursery): JsonResponse
    {
        return response()->json(['data' => $this->findTenantNursery($request, $nursery)->loadCount('rooms')]);
    }

    public function update(Request $request, int $nursery): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $record = $this->findTenantNursery($request, $nursery);
        $data = $request->validate([
            'name' => ['sometimes', 'required', 'string', 'max:120', Rule::unique('nurseries', 'name')->where('tenant_id', $tenant)->ignore($record->id)],
            'address' => ['sometimes', 'nullable', 'string', 'max:255'],
        ]);
        $record->update($data);
        return response()->json(['data' => $record->refresh()]);
    }

    public function destroy(Request $request, int $nursery): JsonResponse
    {
        $record = $this->findTenantNursery($request, $nursery);
        if ($record->rooms()->exists() || $record->children()->exists()) {
            throw new ConflictHttpException('Move or delete this nursery’s rooms and children before deleting the nursery.');
        }
        $record->delete();
        return response()->json(['message' => 'Nursery deleted.']);
    }

    private function findTenantNursery(Request $request, int $id): Nursery
    {
        $record = Nursery::query()->where('tenant_id', $request->attributes->get('tenant_id'))->find($id);
        if (!$record) throw new NotFoundHttpException('Nursery not found for this tenant.');
        return $record;
    }
}
