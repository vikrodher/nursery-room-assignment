<?php

namespace App\Http\Controllers;

use App\Models\Child;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpKernel\Exception\ConflictHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class ChildController
{
    public function index(Request $request): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $children = Child::query()->where('tenant_id', $tenant)
            ->with(['nursery:id,name'])
            ->withExists(['checkIns as is_checked_in' => fn ($query) => $query
                ->where('tenant_id', $tenant)->whereNull('checked_out_at')])
            ->orderBy('name')->get();
        return response()->json(['data' => $children]);
    }

    public function store(Request $request): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $data = $request->validate([
            'nursery_id' => ['required', 'integer', Rule::exists('nurseries', 'id')->where('tenant_id', $tenant)],
            'name' => ['required', 'string', 'max:120'],
        ]);
        $duplicate = Child::query()->where('tenant_id', $tenant)->where('nursery_id', $data['nursery_id'])->whereRaw('LOWER(name) = ?', [mb_strtolower(trim($data['name']))])->exists();
        if ($duplicate) return response()->json(['message' => 'A child with this name already exists in this nursery.'], 422);
        $child = Child::query()->create(['tenant_id' => $tenant, 'nursery_id' => $data['nursery_id'], 'name' => trim($data['name'])]);
        return response()->json(['data' => $child->load('nursery:id,name')], 201);
    }

    public function show(Request $request, int $child): JsonResponse
    {
        return response()->json(['data' => $this->findTenantChild($request, $child)->load('nursery:id,name')]);
    }

    public function update(Request $request, int $child): JsonResponse
    {
        $tenant = (string) $request->attributes->get('tenant_id');
        $record = $this->findTenantChild($request, $child);
        $data = $request->validate([
            'nursery_id' => ['sometimes', 'required', 'integer', Rule::exists('nurseries', 'id')->where('tenant_id', $tenant)],
            'name' => ['sometimes', 'required', 'string', 'max:120'],
        ]);
        $targetNursery = (int) ($data['nursery_id'] ?? $record->nursery_id);
        if ($targetNursery !== (int) $record->nursery_id && $record->checkIns()->whereNull('checked_out_at')->exists()) {
            throw new ConflictHttpException('Check the child out before transferring them to another nursery.');
        }
        $targetName = trim((string) ($data['name'] ?? $record->name));
        $duplicate = Child::query()->where('tenant_id', $tenant)->where('nursery_id', $targetNursery)
            ->whereRaw('LOWER(name) = ?', [mb_strtolower($targetName)])->where('id', '!=', $record->id)->exists();
        if ($duplicate) return response()->json(['message' => 'A child with this name already exists in this nursery.'], 422);
        $record->update([...$data, 'name' => $targetName, 'nursery_id' => $targetNursery]);
        return response()->json(['data' => $record->refresh()->load('nursery:id,name')]);
    }

    public function destroy(Request $request, int $child): JsonResponse
    {
        $record = $this->findTenantChild($request, $child);
        if ($record->checkIns()->exists()) throw new ConflictHttpException('This child has attendance history; the record cannot be deleted.');
        if ($record->guardianUsers()->exists()) throw new ConflictHttpException('This child has linked guardian accounts. Delete those guardian accounts before deleting the child.');
        $record->delete();
        return response()->json(['message' => 'Child deleted.']);
    }

    private function findTenantChild(Request $request, int $id): Child
    {
        $record = Child::query()->where('tenant_id', $request->attributes->get('tenant_id'))->find($id);
        if (!$record) throw new NotFoundHttpException('Child not found for this tenant.');
        return $record;
    }
}
