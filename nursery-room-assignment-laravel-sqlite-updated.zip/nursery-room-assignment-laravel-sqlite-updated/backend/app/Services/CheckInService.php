<?php

namespace App\Services;

use App\Models\CheckIn;
use App\Models\Child;
use App\Models\Room;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\ConflictHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class CheckInService
{
    public function checkIn(string $tenantId, int $roomId, int $childId): CheckIn
    {
        return DB::transaction(function () use ($tenantId, $roomId, $childId): CheckIn {
            $room = Room::query()->where('tenant_id', $tenantId)->find($roomId);
            if (!$room) throw new NotFoundHttpException('Room not found for this tenant.');

            $child = Child::query()->where('tenant_id', $tenantId)->lockForUpdate()->find($childId);
            if (!$child) {
                throw ValidationException::withMessages(['child_id' => ['The selected child does not belong to this tenant.']]);
            }

            // This checks all nurseries and rooms belonging to this customer tenant.
            $activeCheckInExists = CheckIn::query()
                ->where('tenant_id', $tenantId)
                ->where('child_id', $childId)
                ->whereNull('checked_out_at')
                ->exists();

            if ($activeCheckInExists) {
                throw new ConflictHttpException('This child is already checked into a room. Check them out before moving rooms.');
            }

            if ((int) $child->nursery_id !== (int) $room->nursery_id) {
                throw ValidationException::withMessages(['child_id' => ['This child is assigned to a different nursery. Transfer the child first.']]);
            }

            return CheckIn::query()->create([
                'tenant_id' => $tenantId,
                'room_id' => $room->id,
                'child_id' => $child->id,
                'checked_in_at' => now(),
            ]);
        });
    }

    public function checkOut(string $tenantId, int $checkInId): CheckIn
    {
        return DB::transaction(function () use ($tenantId, $checkInId): CheckIn {
            $checkIn = CheckIn::query()->where('tenant_id', $tenantId)->whereNull('checked_out_at')->find($checkInId);
            if (!$checkIn) throw new NotFoundHttpException('Active check-in not found for this tenant.');
            $checkIn->update(['checked_out_at' => now()]);
            return $checkIn->refresh();
        });
    }
}
