<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Child extends Model
{
    protected $fillable = ['tenant_id', 'nursery_id', 'name'];

    public function nursery(): BelongsTo
    {
        return $this->belongsTo(Nursery::class);
    }

    public function checkIns(): HasMany
    {
        return $this->hasMany(CheckIn::class);
    }

    public function guardianUsers(): HasMany
    {
        return $this->hasMany(User::class, 'child_id');
    }

    public function guardians(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'child_user')->withPivot('tenant_id')->withTimestamps();
    }
}
