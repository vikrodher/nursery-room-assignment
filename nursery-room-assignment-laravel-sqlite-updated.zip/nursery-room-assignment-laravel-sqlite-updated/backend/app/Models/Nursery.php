<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Nursery extends Model
{
    protected $fillable = ['tenant_id', 'name', 'address'];

    public function rooms(): HasMany
    {
        return $this->hasMany(Room::class);
    }

    public function children(): HasMany
    {
        return $this->hasMany(Child::class);
    }
}
