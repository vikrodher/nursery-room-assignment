<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = ['tenant_id', 'name', 'email', 'password', 'role', 'child_id'];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class, 'tenant_id');
    }

    public function child(): BelongsTo
    {
        return $this->belongsTo(Child::class, 'child_id');
    }

    public function children(): BelongsToMany
    {
        return $this->belongsToMany(Child::class, 'child_user')->withPivot('tenant_id')->withTimestamps();
    }

    public function publicProfile(): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'tenant_id' => $this->tenant_id,
            'tenant_name' => $this->tenant?->name ?? $this->tenant_id,
            'role' => $this->role ?? 'staff',
            'child_id' => $this->child_id,
            'child_name' => $this->child?->name,
            'children' => $this->children()->pluck('children.name')->all(),
        ];
    }
}
