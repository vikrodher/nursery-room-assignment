
<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CheckInController;
use App\Http\Controllers\ChildController;
use App\Http\Controllers\GuardianAttendanceController;
use App\Http\Controllers\NurseryController;
use App\Http\Controllers\RoomController;
use App\Http\Controllers\RoomOccupantController;
use App\Http\Controllers\UserController;
use App\Http\Middleware\RequireRoles;
use App\Http\Middleware\RequireTenant;
use Illuminate\Support\Facades\Route;

// Public authentication routes
Route::post('/auth/register', [AuthController::class, 'register'])
    ->middleware('throttle:register');

Route::post('/auth/login', [AuthController::class, 'login'])
    ->middleware('throttle:login');

// Authenticated API routes
Route::middleware(['auth:sanctum', RequireTenant::class])->group(function (): void {
    Route::get('/auth/me', [AuthController::class, 'me']);
    Route::post('/auth/logout', [AuthController::class, 'logout']);

    Route::get('/guardian/attendance', GuardianAttendanceController::class)
        ->middleware(RequireRoles::class . ':guardian');

    // Managers and staff can manage nursery operations
    Route::middleware([RequireRoles::class . ':manager,staff'])->group(function (): void {
        Route::post('/rooms/{room}/check-ins', [CheckInController::class, 'store']);
        Route::post('/check-ins/{checkIn}/check-out', [CheckInController::class, 'checkOut']);

        Route::get('/rooms/{room}/occupants', RoomOccupantController::class);

        // Nursery API
        Route::apiResource('nurseries', NurseryController::class)->names([
            'index' => 'api.nurseries.index',
            'store' => 'api.nurseries.store',
            'show' => 'api.nurseries.show',
            'update' => 'api.nurseries.update',
            'destroy' => 'api.nurseries.destroy',
        ]);

        // Room API
        Route::apiResource('rooms', RoomController::class)->names([
            'index' => 'api.rooms.index',
            'store' => 'api.rooms.store',
            'show' => 'api.rooms.show',
            'update' => 'api.rooms.update',
            'destroy' => 'api.rooms.destroy',
        ]);

        // Child API
        Route::apiResource('children', ChildController::class)->names([
            'index' => 'api.children.index',
            'store' => 'api.children.store',
            'show' => 'api.children.show',
            'update' => 'api.children.update',
            'destroy' => 'api.children.destroy',
        ]);
    });

    // User API remains authenticated and tenant-scoped.
    // Managers and staff retain the existing middleware behavior.
    Route::apiResource('users', UserController::class)->names([
        'index' => 'api.users.index',
        'store' => 'api.users.store',
        'show' => 'api.users.show',
        'update' => 'api.users.update',
        'destroy' => 'api.users.destroy',
    ]);
});
