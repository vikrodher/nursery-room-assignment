<?php

use App\Http\Controllers\WebController;
use Illuminate\Support\Facades\Route;

Route::get('/', [WebController::class, 'home'])->name('home');
// A GET /login endpoint is needed when Laravel redirects back after invalid credentials.
Route::get('/login', [WebController::class, 'home'])->name('login.form');
Route::middleware('guest')->group(function () {
    Route::post('/register', [WebController::class, 'register'])->middleware('throttle:register')->name('register');
    Route::post('/login', [WebController::class, 'login'])->middleware('throttle:login')->name('login');
});
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [WebController::class, 'dashboard'])->name('dashboard');
    Route::post('/logout', [WebController::class, 'logout'])->name('logout');
    Route::post('/nurseries', [WebController::class, 'saveNursery'])->name('nurseries.store');
    Route::delete('/nurseries/{nursery}', [WebController::class, 'deleteNursery'])->name('nurseries.delete');
    Route::post('/rooms', [WebController::class, 'saveRoom'])->name('rooms.store');
    Route::delete('/rooms/{room}', [WebController::class, 'deleteRoom'])->name('rooms.delete');
    Route::post('/children', [WebController::class, 'saveChild'])->name('children.store');
    Route::delete('/children/{child}', [WebController::class, 'deleteChild'])->name('children.delete');
    Route::post('/users', [WebController::class, 'saveUser'])->name('users.store');
    Route::delete('/users/{target}', [WebController::class, 'deleteUser'])->name('users.delete');
    Route::post('/parent-child-assignments', [WebController::class, 'saveParentChildAssignments'])->name('assignments.store');
    Route::put('/parent-child-assignments/{parent}', [WebController::class, 'updateParentChildAssignments'])->name('assignments.update');
    Route::delete('/parent-child-assignments/{parent}/{child}', [WebController::class, 'removeParentChildAssignment'])->name('assignments.delete');
    Route::post('/rooms/{room}/check-in', [WebController::class, 'checkIn'])->name('attendance.checkin');
    Route::post('/check-ins/{checkIn}/check-out', [WebController::class, 'checkOut'])->name('attendance.checkout');
});
