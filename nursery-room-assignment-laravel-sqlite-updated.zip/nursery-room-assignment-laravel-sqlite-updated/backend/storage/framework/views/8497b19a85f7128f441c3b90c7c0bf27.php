<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
  <?php if(session('success')): ?>
    <div class="alert success" role="status"><?php echo e(session('success')); ?></div>
  <?php endif; ?>
  <?php if($errors->any()): ?>
    <div class="alert error" role="alert">
      <strong>Please fix the following:</strong>
      <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>
  <div class="page-heading">
    <div><span class="eyebrow">WORKSPACE</span>
      <h1><?php echo e($user->tenant->name ?? 'Nursery workspace'); ?></h1>
      <p class="muted">Manage nursery locations, rooms, children and live attendance.</p>
    </div><span class="role-pill"><?php echo e(ucfirst($user->role)); ?></span>
  </div>
  <div class="stats">
    <div class="stat"><span>Nurseries</span><strong><?php echo e($nurseries->count()); ?></strong></div>
    <div class="stat"><span>Rooms</span><strong><?php echo e($rooms->count()); ?></strong></div>
    <div class="stat"><span>Children</span><strong><?php echo e($children->count()); ?></strong></div>
    <div class="stat"><span>Checked in
        now</span><strong><?php echo e($children->filter(fn($c) => $c->checkIns->isNotEmpty())->count()); ?></strong></div>
  </div>
  <div class="section-grid">
    <section class="panel">
      <div class="section-title">
        <div>
          <h2>Nurseries</h2>
          <p class="muted">Create each location in your group.</p>
        </div>
      </div>
      <form method="POST" action="<?php echo e(route('nurseries.store')); ?>" class="inline-form"><?php echo csrf_field(); ?><input name="name"
          placeholder="Nursery name" maxlength="120" required><input name="address" placeholder="Address (optional)"
          maxlength="255"><button class="button primary">Add nursery</button></form>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Nursery</th>
              <th>Address</th>
              <th>Rooms</th>
              <th>Children</th>
              <th></th>
            </tr>
          </thead>
          <tbody><?php $__empty_1 = true; $__currentLoopData = $nurseries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><strong><?php echo e($n->name); ?></strong></td>
              <td><?php echo e($n->address ?: '—'); ?></td>
              <td><?php echo e($n->rooms_count); ?></td>
              <td><?php echo e($n->children_count); ?></td>
              <td>
                <form method="POST" action="<?php echo e(route('nurseries.delete', $n)); ?>"
                  onsubmit="return confirm('Delete this nursery?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="link danger" <?php echo e(($n->rooms_count || $n->children_count) ? 'disabled' : ''); ?>>Delete</button></form>
              </td>
          </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr>
              <td colspan="5" class="empty">No nurseries yet. Create one above.</td>
            </tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>
    <section class="panel">
      <h2>Add a room</h2>
      <p class="muted">Rooms belong to one nursery.</p>
      <form method="POST" action="<?php echo e(route('rooms.store')); ?>" class="stack"><?php echo csrf_field(); ?><label>Nursery<select name="nursery_id"
            required>
            <option value="">Choose nursery</option><?php $__currentLoopData = $nurseries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($n->id); ?>"><?php echo e($n->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select></label><label>Room name<input name="name" maxlength="120" placeholder="e.g. Bluebirds"
            required></label><button class="button primary" <?php echo e($nurseries->isEmpty() ? 'disabled' : ''); ?>>Create room</button>
      </form>
    </section>
    <section class="panel">
      <h2>Add a child</h2>
      <p class="muted">Assign the child to their home nursery.</p>
      <form method="POST" action="<?php echo e(route('children.store')); ?>" class="stack"><?php echo csrf_field(); ?><label>Nursery<select
            name="nursery_id" required>
            <option value="">Choose nursery</option><?php $__currentLoopData = $nurseries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($n->id); ?>"><?php echo e($n->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select></label><label>Child's full name<input name="name" maxlength="120" required></label><button
          class="button primary" <?php echo e($nurseries->isEmpty() ? 'disabled' : ''); ?>>Add child</button></form>
    </section>
    <?php if($user->role === 'manager'): ?>
      <section class="panel">
        <h2>Create staff or guardian login</h2>
        <p class="muted">You can assign one or more children to this parent in Parent–Child Assignments below.</p>
        <form method="POST" action="<?php echo e(route('users.store')); ?>" class="stack"><?php echo csrf_field(); ?><label>Full name<input name="name"
              maxlength="120" required></label><label>Email<input type="email" name="email"
              required></label><label>Temporary password<input type="password" name="password" minlength="8"
              required></label><label>Confirm password<input type="password" name="password_confirmation" minlength="8"
              required></label><label>Role<select name="role" id="new-role" required>
              <option value="staff">Staff</option>
              <option value="guardian">Parent / Guardian</option>
            </select></label><label id="child-choice">Linked child<select name="child_id">
              <option value="">Select a child for guardian</option><?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?> — <?php echo e($c->nursery?->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></label><button class="button dark">Create account</button></form>
        <script>const roleSelect = document.getElementById('new-role'), childChoice = document.getElementById('child-choice'); function syncRole() { childChoice.style.display = roleSelect.value === 'guardian' ? 'grid' : 'none'; childChoice.querySelector('select').required = roleSelect.value === 'guardian' } roleSelect.addEventListener('change', syncRole); syncRole();</script>
    </section><?php endif; ?>
  </div>
  <?php if($user->role === 'manager'): ?>
    <section class="panel assignment-panel" style="margin-top:16px">
      <div class="section-title">
        <div>
          <h2>Parent–Child Assignments</h2>
          <p class="muted">Assign multiple children to an existing parent account. Adding children preserves current links.
          </p>
        </div>
      </div>
      <form method="POST" action="<?php echo e(route('assignments.store')); ?>" class="stack"><?php echo csrf_field(); ?>
        <label>Parent / guardian account<select name="parent_id" required>
            <option value="">Choose parent account</option><?php $__currentLoopData = $guardianAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($parent->id); ?>" <?php if(old('parent_id') == $parent->id): echo 'selected'; endif; ?>><?php echo e($parent->name); ?> —
            <?php echo e($parent->email); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select></label>
        <label>Children to assign<select name="child_ids[]" multiple size="5" required><?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($child->id); ?>" <?php if(collect(old('child_ids', []))->contains($child->id)): echo 'selected'; endif; ?>>
        <?php echo e($child->name); ?> — <?php echo e($child->nursery?->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select><small class="muted">Hold Ctrl (Windows) to select more than one child.</small></label>
        <button class="button primary" <?php echo e($guardianAccounts->isEmpty() || $children->isEmpty() ? 'disabled' : ''); ?>>Assign
          selected children</button>
      </form>
      <h3 style="margin-top:22px">Current assignments</h3>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Parent</th>
              <th>Email</th>
              <th>Assigned children</th>
              <th>Manage</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $guardianAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><strong><?php echo e($parent->name); ?></strong></td>
                <td><?php echo e($parent->email); ?></td>
                <td><?php echo e($parent->children->pluck('name')->join(', ') ?: ($parent->child?->name ?? 'No children assigned')); ?>

                </td>
                <td>
                  <details>
                    <summary>Edit</summary>
                    <form method="POST" action="<?php echo e(route('assignments.update', $parent)); ?>" class="stack"
                      style="min-width:220px;margin-top:8px"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?><label>Linked children<select
                          name="child_ids[]" multiple size="5"><?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($child->id); ?>" <?php if($parent->children->contains('id', $child->id) || ($parent->children->isEmpty() && $parent->child_id == $child->id)): echo 'selected'; endif; ?>><?php echo e($child->name); ?> —
                          <?php echo e($child->nursery?->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select></label><button class="button small">Save assignments</button></form>
                  </details><?php $__currentLoopData = $parent->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="<?php echo e(route('assignments.delete', [$parent, $linked])); ?>" style="display:inline"
                      onsubmit="return confirm('Remove <?php echo e(addslashes($linked->name)); ?> from this parent?')"><?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?><button class="link danger">Remove <?php echo e($linked->name); ?></button></form> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr>
              <td colspan="4" class="empty">Create a parent/guardian login first, then assign children here.</td>
            </tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>
  <?php endif; ?>
  <div class="section-grid lower-grid">
    <section class="panel wide">
      <h2>Room attendance</h2>
      <p class="muted">Check children in and out. Children can only enter rooms in their assigned nursery.</p>
      <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="room-card">
          <div class="room-head">
            <div>
              <h3><?php echo e($room->name); ?></h3><span class="muted"><?php echo e($room->nursery?->name); ?></span>
            </div><span class="count-pill"><?php echo e($room->checkIns->count()); ?> present</span>
            <form method="POST" action="<?php echo e(route('rooms.delete', $room)); ?>" onsubmit="return confirm('Delete this room?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="link danger" <?php echo e($room->checkIns()->exists() ? 'disabled' : ''); ?>>Delete
                room</button></form>
          </div>
          <div class="attendance-list"><?php $__empty_2 = true; $__currentLoopData = $room->checkIns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $active): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
            <div class="attendance-row">
              <div><strong><?php echo e($active->child?->name); ?></strong><small>Checked in
                  <?php echo e($active->checked_in_at?->format('d M Y, h:i A')); ?></small></div>
              <form method="POST" action="<?php echo e(route('attendance.checkout', $active)); ?>"><?php echo csrf_field(); ?><button
                  class="button small">Check out</button></form>
          </div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><p class="empty">No children currently in this room.</p><?php endif; ?>
          </div>
          <form method="POST" action="<?php echo e(route('attendance.checkin', $room)); ?>" class="inline-form checkin-form"><?php echo csrf_field(); ?><select
              name="child_id" required>
              <option value="">Select child to check in</option>
              <?php $__currentLoopData = $children->where('nursery_id', $room->nursery_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if($child->checkIns->isEmpty()): ?>
              <option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><button class="button primary">Check in</button></form>
      </div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty">Create a nursery and room to begin attendance.</div><?php endif; ?>
    </section>
    <section class="panel wide">
      <h2>Children</h2>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Child</th>
              <th>Nursery</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody><?php $__empty_1 = true; $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><strong><?php echo e($child->name); ?></strong></td>
              <td><?php echo e($child->nursery?->name); ?></td>
              <td><?php if($child->checkIns->isNotEmpty()): ?><span class="status in">Checked in ·
              <?php echo e($child->checkIns->first()->room?->name); ?></span><?php else: ?><span class="status out">Checked
                  out</span><?php endif; ?></td>
              <td>
                <form method="POST" action="<?php echo e(route('children.delete', $child)); ?>"
                  onsubmit="return confirm('Delete this child?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="link danger" <?php echo e(($child->checkIns()->exists() || $child->guardianUsers()->exists()) ? 'disabled' : ''); ?>>Delete</button>
                </form>
              </td>
          </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr>
              <td colspan="4" class="empty">No children created yet.</td>
            </tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>
    <?php if($user->role === 'manager'): ?>
      <section class="panel wide">
        <h2>Workspace accounts</h2>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Linked child</th>
                <th></th>
              </tr>
            </thead>
            <tbody><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($account->name); ?> <?php if($account->id === $user->id): ?><span class="muted">(you)</span><?php endif; ?></td>
                <td><?php echo e($account->email); ?></td>
                <td><?php echo e(ucfirst($account->role)); ?></td>
                <td><?php echo e($account->role === 'guardian' ? ($account->child?->name ?? 'Not linked') : '—'); ?></td>
                <td><?php if($account->role !== 'manager' && $account->id !== $user->id): ?>
                  <form method="POST" action="<?php echo e(route('users.delete', $account)); ?>"
                    onsubmit="return confirm('Delete this account?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button
                class="link danger">Delete</button></form><?php else: ?><span class="muted">Protected</span><?php endif; ?>
                </td>
            </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
    </section><?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\adity\Downloads\final\nursery-room-assignment-laravel-sqlite-updated\backend\resources\views/dashboard.blade.php ENDPATH**/ ?>