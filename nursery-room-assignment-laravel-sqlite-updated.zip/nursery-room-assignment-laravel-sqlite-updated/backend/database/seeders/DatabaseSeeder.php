<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Intentionally empty. Real tenant, user, nursery, room, and child records
        // are created through the application. Tests create their own isolated fixtures.
    }
}
