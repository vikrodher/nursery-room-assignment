<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->foreignId('child_id')->nullable()->after('role')->constrained('children')->restrictOnDelete();
            $table->index(['tenant_id', 'child_id']);
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->dropIndex(['tenant_id', 'child_id']);
            $table->dropConstrainedForeignId('child_id');
        });
    }
};
