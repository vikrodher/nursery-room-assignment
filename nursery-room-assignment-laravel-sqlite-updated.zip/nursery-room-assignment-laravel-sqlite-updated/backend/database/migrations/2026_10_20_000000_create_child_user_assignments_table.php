<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('child_user', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('child_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('tenant_id');
            $table->timestamps();
            $table->unique(['child_id', 'user_id']);
            $table->index(['tenant_id', 'user_id']);
        });

        // Preserve existing one-child guardian links during migration.
        if (Schema::hasColumn('users', 'child_id')) {
            $now = now();
            $legacy = DB::table('users')->where('role', 'guardian')->whereNotNull('child_id')->get(['id', 'child_id', 'tenant_id']);
            foreach ($legacy as $row) {
                DB::table('child_user')->updateOrInsert(
                    ['child_id' => $row->child_id, 'user_id' => $row->id],
                    ['tenant_id' => $row->tenant_id, 'created_at' => $now, 'updated_at' => $now]
                );
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('child_user');
    }
};
