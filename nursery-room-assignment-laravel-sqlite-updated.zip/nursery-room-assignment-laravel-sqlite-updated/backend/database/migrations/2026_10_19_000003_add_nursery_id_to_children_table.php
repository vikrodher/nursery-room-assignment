<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('children', function (Blueprint $table): void {
            $table->foreignId('nursery_id')->nullable()->after('tenant_id')->constrained('nurseries')->restrictOnDelete();
            $table->index(['tenant_id', 'nursery_id']);
        });
    }

    public function down(): void
    {
        Schema::table('children', function (Blueprint $table): void {
            $table->dropIndex(['tenant_id', 'nursery_id']);
            $table->dropConstrainedForeignId('nursery_id');
        });
    }
};
