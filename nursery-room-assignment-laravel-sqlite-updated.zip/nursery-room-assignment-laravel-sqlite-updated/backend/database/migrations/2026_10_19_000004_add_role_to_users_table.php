<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->string('role', 20)->default('staff')->index();
        });

        // On upgrades, preserve the earliest account in each group as its manager.
        // Accounts created after that first account remain staff by default.
        $tenantIds = DB::table('users')->select('tenant_id')->distinct()->pluck('tenant_id');
        foreach ($tenantIds as $tenantId) {
            $firstUserId = DB::table('users')->where('tenant_id', $tenantId)->orderBy('id')->value('id');
            if ($firstUserId !== null) {
                DB::table('users')->where('id', $firstUserId)->update(['role' => 'manager']);
            }
        }
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->dropIndex(['role']);
            $table->dropColumn('role');
        });
    }
};
